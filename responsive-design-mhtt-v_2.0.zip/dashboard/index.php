<?php
    header("Location: ./projects")
?>